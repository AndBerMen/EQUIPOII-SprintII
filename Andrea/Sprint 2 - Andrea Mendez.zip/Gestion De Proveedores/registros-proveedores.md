1. Nombre fiscal: Suministros Técnicos S.L.
   Nombre comercial: TechSupply
   NIF: B12345678
   Dirección: Calle Innovación, 23
   Código postal: 28001
   Ciudad: Madrid
   Provincia: Madrid
   País: España
   Correo electrónico: info@techsupply.es
   Teléfono: +34 911234567

2. Nombre fiscal: Componentes Electrónicos Avanzados S.A.
   Nombre comercial: ElectroComp
   NIF: A87654321
   Dirección: Avenida de la Tecnología, 45
   Código postal: 08001
   Ciudad: Barcelona
   Provincia: Barcelona
   País: España
   Correo electrónico: contacto@electrocomp.com
   Teléfono: +34 931234567

3. Nombre fiscal: Maquinaria Industrial del Norte S.L.
   Nombre comercial: NorMaq
   NIF: B98765432
   Dirección: Polígono Industrial El Progreso, Nave 12
   Código postal: 48001
   Ciudad: Bilbao
   Provincia: Vizcaya
   País: España
   Correo electrónico: ventas@normaq.es
   Teléfono: +34 944567890

4. Nombre fiscal: Distribuciones Alimentarias del Sur S.A.
   Nombre comercial: AlimSur
   NIF: A23456789
   Dirección: Carretera de Málaga, Km 5
   Código postal: 41001
   Ciudad: Sevilla
   Provincia: Sevilla
   País: España
   Correo electrónico: pedidos@alimsur.com
   Teléfono: +34 954321098

5. Nombre fiscal: Productos Químicos Mediterráneos S.L.
   Nombre comercial: MedQuim
   NIF: B34567890
   Dirección: Calle de la Industria, 78
   Código postal: 46001
   Ciudad: Valencia
   Provincia: Valencia
   País: España
   Correo electrónico: info@medquim.es
   Teléfono: +34 961235678

6. Nombre fiscal: Soluciones Informáticas Gallegas S.A.
   Nombre comercial: GaliciaSoft
   NIF: A45678901
   Dirección: Rúa da Programación, 10
   Código postal: 15001
   Ciudad: A Coruña
   Provincia: A Coruña
   País: España
   Correo electrónico: soporte@galiciasoft.es
   Teléfono: +34 981876543

7. Nombre fiscal: Transportes Rápidos de Castilla S.L.
   Nombre comercial: TransCastilla
   NIF: B56789012
   Dirección: Avenida del Transporte, 34
   Código postal: 47001
   Ciudad: Valladolid
   Provincia: Valladolid
   País: España
   Correo electrónico: logistica@transcastilla.com
   Teléfono: +34 983456789

8. Nombre fiscal: Materiales de Construcción Levante S.A.
   Nombre comercial: ConstruLevante
   NIF: A67890123
   Dirección: Polígono Industrial El Constructor, Parcela 5
   Código postal: 03001
   Ciudad: Alicante
   Provincia: Alicante
   País: España
   Correo electrónico: ventas@construlevante.es
   Teléfono: +34 965432109

9. Nombre fiscal: Energías Renovables de Aragón S.L.
   Nombre comercial: EcoAragón
   NIF: B78901234
   Dirección: Paseo de la Sostenibilidad, 56
   Código postal: 50001
   Ciudad: Zaragoza
   Provincia: Zaragoza
   País: España
   Correo electrónico: info@ecoaragon.com
   Teléfono: +34 976543210

10. Nombre fiscal: Muebles y Decoración Andaluza S.A.
    Nombre comercial: AndaluDecor
    NIF: A89012345
    Dirección: Calle del Diseño, 89
    Código postal: 29001
    Ciudad: Málaga
    Provincia: Málaga
    País: España
    Correo electrónico: clientes@andaludecor.es
    Teléfono: +34 952345678

11. Nombre fiscal: Suministros Médicos del Cantábrico S.L.
    Nombre comercial: MedCantábrico
    NIF: B90123456
    Dirección: Avenida de la Salud, 23
    Código postal: 39001
    Ciudad: Santander
    Provincia: Cantabria
    País: España
    Correo electrónico: pedidos@medcantabrico.com
    Teléfono: +34 942678901

12. Nombre fiscal: Productos Cárnicos de Extremadura S.A.
    Nombre comercial: ExtremaCarne
    NIF: A01234567
    Dirección: Carretera de la Dehesa, Km 3
    Código postal: 06001
    Ciudad: Badajoz
    Provincia: Badajoz
    País: España
    Correo electrónico: ventas@extremacarne.es
    Teléfono: +34 924789012

13. Nombre fiscal: Servicios Turísticos Baleares S.L.
    Nombre comercial: BalearTour
    NIF: B12345679
    Dirección: Paseo Marítimo, 100
    Código postal: 07001
    Ciudad: Palma de Mallorca
    Provincia: Islas Baleares
    País: España
    Correo electrónico: reservas@baleartour.com
    Teléfono: +34 971890123

14. Nombre fiscal: Productos Lácteos de Asturias S.A.
    Nombre comercial: AsturLácteos
    NIF: A23456780
    Dirección: Camino de los Pastos, 45
    Código postal: 33001
    Ciudad: Oviedo
    Provincia: Asturias
    País: España
    Correo electrónico: info@asturlacteos.es
    Teléfono: +34 985901234

15. Nombre fiscal: Sistemas de Seguridad Canarios S.L.
    Nombre comercial: CanarySafe
    NIF: B34567891
    Dirección: Calle de la Protección, 67
    Código postal: 35001
    Ciudad: Las Palmas de Gran Canaria
    Provincia: Las Palmas
    País: España
    Correo electrónico: seguridad@canarysafe.com
    Teléfono: +34 928012345

16. Nombre fiscal: Vinos y Licores de La Rioja S.A.
    Nombre comercial: RiojaSpirits
    NIF: A45678902
    Dirección: Carretera del Vino, Km 7
    Código postal: 26001
    Ciudad: Logroño
    Provincia: La Rioja
    País: España
    Correo electrónico: pedidos@riojaspirits.es
    Teléfono: +34 941123456

17. Nombre fiscal: Tecnologías de la Información Murcianas S.L.
    Nombre comercial: MurciaTech
    NIF: B56789013
    Dirección: Avenida de la Informática, 34
    Código postal: 30001
    Ciudad: Murcia
    Provincia: Murcia
    País: España
    Correo electrónico: soporte@murciatech.com
    Teléfono: +34 968234567

18. Nombre fiscal: Productos Agrícolas de Castilla-La Mancha S.A.
    Nombre comercial: AgroCastilla
    NIF: A67890124
    Dirección: Camino de los Cultivos, 56
    Código postal: 02001
    Ciudad: Albacete
    Provincia: Albacete
    País: España
    Correo electrónico: ventas@agrocastilla.es
    Teléfono: +34 967345678

19. Nombre fiscal: Servicios Logísticos de Navarra S.L.
    Nombre comercial: NavarraLog
    NIF: B78901235
    Dirección: Polígono Industrial El Transporte, Nave 23
    Código postal: 31001
    Ciudad: Pamplona
    Provincia: Navarra
    País: España
    Correo electrónico: logistica@navarralog.com
    Teléfono: +34 948456789

20. Nombre fiscal: Equipamiento Deportivo Vasco S.A.
    Nombre comercial: EuskalSport
    NIF: A89012346
    Dirección: Calle del Deporte, 89
    Código postal: 01001
    Ciudad: Vitoria-Gasteiz
    Provincia: Álava
    País: España
    Correo electrónico: info@euskalsport.es
    Teléfono: +34 945567890
